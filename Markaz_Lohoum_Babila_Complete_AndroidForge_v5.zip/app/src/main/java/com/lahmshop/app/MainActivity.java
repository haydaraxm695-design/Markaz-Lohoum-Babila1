package com.lahmshop.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.net.Uri;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class MainActivity extends Activity {
    FirebaseFirestore db; FirebaseAuth auth; FirebaseStorage storage;
    ListenerRegistration productsListener;
    LinearLayout list;
    ArrayList<Product> products = new ArrayList<>();
    final int RED=Color.rgb(170,20,25), LIGHT=Color.rgb(255,245,240), GREEN=Color.rgb(0,150,70);
    final int PICK_IMAGE=2001, PICK_VIDEO=2002;
    String mediaProductId=null;
    final String WA1="963960987637", WA2="963944483343";

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(45,45,45));
        t.setGravity(Gravity.RIGHT); t.setPadding(dp(10),dp(8),dp(10),dp(8));
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    Button btn(String text){
        Button b=new Button(this); b.setText(text); b.setTextSize(15); b.setAllCaps(false); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); db=FirebaseFirestore.getInstance(); auth=FirebaseAuth.getInstance(); storage=FirebaseStorage.getInstance(); listenProducts();
    }

    void listenProducts(){
        if(productsListener!=null)productsListener.remove();
        db.collection("products").orderBy("name").addSnapshotListener((snap,e)->{
            if(e!=null||snap==null){ if(products.isEmpty())seed(); showHome(); return; }
            products.clear();
            for(DocumentSnapshot d:snap.getDocuments()){
                String n=d.getString("name"),u=d.getString("unit"),img=d.getString("imageUrl"),vid=d.getString("videoUrl"),cat=d.getString("category");
                Double p=d.getDouble("price"); Boolean o=d.getBoolean("offer");
                if(n!=null&&p!=null){ if(cat==null||cat.isEmpty())cat=inferCategory(n); products.add(new Product(d.getId(),n,u==null?"كيلو":u,p,o!=null&&o,img,vid,cat)); }
            }
            showHome();
        });
    }

    String inferCategory(String name){
        String n=name==null?"":name;
        if(n.contains("دجاج")||n.contains("جاج")) return "جاج";
        if(n.contains("غنم")||n.contains("خروف")||n.contains("ريش")||n.contains("كفتة غنم")) return "غنم";
        return "عجل";
    }

    void seed(){
        products.clear();
        products.add(new Product("local_1","لحم عجل طازج","كيلو",12.99,false,null,null,"عجل"));
        products.add(new Product("local_2","دجاج طازج","كيلو",5.99,false,null,null,"جاج"));
        products.add(new Product("local_3","لحم غنم","كيلو",14.99,false,null,null,"غنم"));
        products.add(new Product("local_4","لحم مفروم","كيلو",10.99,true,null,null,"عجل"));
    }

    void base(String title, boolean home){
        LinearLayout main=new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL); main.setBackgroundColor(Color.WHITE); main.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView head=tv(title,24,true); head.setTextColor(Color.WHITE); head.setGravity(Gravity.CENTER); head.setBackgroundColor(RED); main.addView(head,new LinearLayout.LayoutParams(-1,dp(62)));
        if(home){
            ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.logo); logo.setScaleType(ImageView.ScaleType.CENTER_CROP); logo.setPadding(dp(12),dp(12),dp(12),dp(12)); main.addView(logo,new LinearLayout.LayoutParams(-1,dp(270)));
            TextView addr=tv("📍 سوريا — دمشق — ببيلا",17,true); addr.setGravity(Gravity.CENTER); main.addView(addr,new LinearLayout.LayoutParams(-1,dp(45)));
            TextView contact=tv("📞 0960987637 — أبو موفق    |    📞 0944483343 — أبو محمد حسان",15,true); contact.setGravity(Gravity.CENTER); main.addView(contact,new LinearLayout.LayoutParams(-1,dp(55)));
        }
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); list.setPadding(dp(12),dp(10),dp(12),dp(20));
        ScrollView sc=new ScrollView(this); sc.addView(list); main.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setPadding(dp(5),dp(4),dp(5),dp(4));
        Button homeBtn=btn("🏠 الرئيسية"), offersBtn=btn("🔥 العروض"), admin=btn("🔐 الإدارة");
        nav.addView(homeBtn,new LinearLayout.LayoutParams(0,dp(56),1)); nav.addView(offersBtn,new LinearLayout.LayoutParams(0,dp(56),1)); nav.addView(admin,new LinearLayout.LayoutParams(0,dp(56),1));
        homeBtn.setOnClickListener(v->showHome()); offersBtn.setOnClickListener(v->showCategory("العروض")); admin.setOnClickListener(v->showAdminLogin());
        main.addView(nav); setContentView(main);
    }

    void showHome(){
        base("🥩 مركز اللحوم ببيلا",true);
        TextView title=tv("اختر القسم",22,true); title.setGravity(Gravity.CENTER); title.setTextColor(RED); list.addView(title);
        LinearLayout r1=new LinearLayout(this), r2=new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL); r2.setOrientation(LinearLayout.HORIZONTAL);
        addCategoryButton(r1,"🍗 جاج","جاج"); addCategoryButton(r1,"🐑 غنم","غنم"); addCategoryButton(r2,"🐄 عجل","عجل"); addCategoryButton(r2,"🔥 العروض","العروض");
        list.addView(r1,new LinearLayout.LayoutParams(-1,dp(72))); list.addView(r2,new LinearLayout.LayoutParams(-1,dp(72)));
        TextView hint=tv("اختار القسم لتشوف المنتجات والأسعار، واضغط زر واتساب للطلب مباشرة.",16,true); hint.setGravity(Gravity.CENTER); list.addView(hint);
        ArrayList<Product> offers=new ArrayList<>(); for(Product p:products)if(p.offer)offers.add(p);
        if(!offers.isEmpty()){
            TextView ot=tv("🔥 عروض اليوم",21,true); ot.setTextColor(RED); list.addView(ot);
            for(Product p:offers) addProductCard(p);
        }
    }

    void addCategoryButton(LinearLayout row,String label,String key){
        Button b=btn(label); b.setTextSize(18); row.addView(b,new LinearLayout.LayoutParams(0,dp(64),1)); b.setOnClickListener(v->showCategory(key));
    }

    void showCategory(String category){
        String title=category.equals("جاج")?"🍗 قسم الجاج":category.equals("غنم")?"🐑 قسم الغنم":category.equals("عجل")?"🐄 قسم العجل":"🔥 العروض";
        base(title,false);
        Button back=btn("⬅ الرئيسية"); back.setOnClickListener(v->showHome()); list.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
        int count=0;
        for(Product p:products){
            boolean match=category.equals("العروض")?p.offer:category.equals(p.category);
            if(match){addProductCard(p);count++;}
        }
        if(count==0){TextView empty=tv("لا توجد منتجات بهذا القسم حاليًا.",18,true);empty.setGravity(Gravity.CENTER);list.addView(empty);}
    }

    void addProductCard(Product p){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(12),dp(10),dp(12),dp(10)); card.setBackgroundColor(LIGHT);
        if(p.offer){TextView o=tv("🔥 عرض اليوم",15,true);o.setTextColor(Color.rgb(0,120,60));card.addView(o);}
        TextView n=tv(p.name,19,true), price=tv(String.format(Locale.US,"%.2f",p.price)+" / "+p.unit,18,true); price.setTextColor(RED); card.addView(n); card.addView(price);
        if(p.imageUrl!=null&&!p.imageUrl.isEmpty()){ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(Color.LTGRAY);card.addView(image,new LinearLayout.LayoutParams(-1,dp(220)));loadImage(p.imageUrl,image);}
        if(p.videoUrl!=null&&!p.videoUrl.isEmpty()){VideoView video=new VideoView(this);video.setBackgroundColor(Color.BLACK);card.addView(video,new LinearLayout.LayoutParams(-1,dp(230)));MediaController mc=new MediaController(this);mc.setAnchorView(video);video.setMediaController(mc);video.setVideoURI(Uri.parse(p.videoUrl));}
        LinearLayout wa=new LinearLayout(this); wa.setOrientation(LinearLayout.HORIZONTAL);
        Button w1=btn("🟢 طلب واتساب\n0960987637"), w2=btn("🟢 طلب واتساب\n0944483343");
        w1.setTextColor(Color.WHITE);w2.setTextColor(Color.WHITE);w1.setBackgroundColor(GREEN);w2.setBackgroundColor(GREEN);
        wa.addView(w1,new LinearLayout.LayoutParams(0,dp(58),1)); wa.addView(w2,new LinearLayout.LayoutParams(0,dp(58),1));
        String message="مرحباً، أريد طلب: "+p.name+" - السعر الظاهر في التطبيق: "+String.format(Locale.US,"%.2f",p.price)+" / "+p.unit;
        w1.setOnClickListener(v->openWhatsApp(WA1,message)); w2.setOnClickListener(v->openWhatsApp(WA2,message)); card.addView(wa);
        list.addView(card,new LinearLayout.LayoutParams(-1,-2)); Space sp=new Space(this);list.addView(sp,new LinearLayout.LayoutParams(1,dp(8)));
    }

    void openWhatsApp(String number,String message){
        try{String url="https://wa.me/"+number+"?text="+URLEncoder.encode(message,"UTF-8");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
        catch(Exception e){Toast.makeText(this,"تعذر فتح واتساب",Toast.LENGTH_SHORT).show();}
    }

    void loadImage(String url,ImageView target){new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setInstanceFollowRedirects(true);InputStream in=c.getInputStream();Bitmap b=BitmapFactory.decodeStream(in);in.close();c.disconnect();if(b!=null)runOnUiThread(()->target.setImageBitmap(b));}catch(Exception ignored){}}).start();}

    void showAdminLogin(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText email=new EditText(this);email.setHint("البريد الإلكتروني للإدارة");EditText pass=new EditText(this);pass.setHint("كلمة المرور");pass.setInputType(0x00000081);box.addView(email);box.addView(pass);
        new AlertDialog.Builder(this).setTitle("دخول الإدارة").setView(box).setPositiveButton("دخول",(d,w)->auth.signInWithEmailAndPassword(email.getText().toString().trim(),pass.getText().toString()).addOnSuccessListener(r->checkAdminAndOpen()).addOnFailureListener(err->Toast.makeText(this,"بيانات الدخول غير صحيحة",Toast.LENGTH_SHORT).show())).setNegativeButton("إلغاء",null).show();
    }
    void checkAdminAndOpen(){if(auth.getCurrentUser()==null)return;String uid=auth.getCurrentUser().getUid();db.collection("users").document(uid).get().addOnSuccessListener(d->{Boolean admin=d.getBoolean("admin");if(Boolean.TRUE.equals(admin))showAdmin();else{auth.signOut();Toast.makeText(this,"هذا الحساب ليس حساب إدارة",Toast.LENGTH_SHORT).show();}}).addOnFailureListener(e->Toast.makeText(this,"تعذر التحقق من صلاحيات الإدارة",Toast.LENGTH_SHORT).show());}

    void showAdmin(){
        base("🔐 لوحة إدارة مركز اللحوم ببيلا",false); list.addView(tv("عدّل الأسعار والعروض والأقسام وارفع صور وفيديوهات من هنا",18,true));
        for(Product p:products){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(8),dp(8),dp(8),dp(8));
            EditText name=new EditText(this);name.setText(p.name);EditText price=new EditText(this);price.setText(String.format(Locale.US,"%.2f",p.price));price.setInputType(2|8192);
            Spinner cat=new Spinner(this);String[] cats={"جاج","غنم","عجل"};ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats);cat.setAdapter(ad);for(int i=0;i<cats.length;i++)if(cats[i].equals(p.category))cat.setSelection(i);
            CheckBox offer=new CheckBox(this);offer.setText("عرض اليوم");offer.setChecked(p.offer);Button save=btn("حفظ السعر والقسم والعرض");
            save.setOnClickListener(v->{try{String nn=name.getText().toString().trim();double np=Double.parseDouble(price.getText().toString());Map<String,Object> data=new HashMap<>();data.put("name",nn);data.put("unit",p.unit);data.put("price",np);data.put("offer",offer.isChecked());data.put("category",cat.getSelectedItem().toString());if(p.imageUrl!=null)data.put("imageUrl",p.imageUrl);if(p.videoUrl!=null)data.put("videoUrl",p.videoUrl);db.collection("products").document(p.id).set(data).addOnSuccessListener(x->Toast.makeText(this,"تم الحفظ وتحديثه عند الزبائن",Toast.LENGTH_SHORT).show()).addOnFailureListener(x->Toast.makeText(this,"تعذر الحفظ",Toast.LENGTH_SHORT).show());}catch(Exception ex){Toast.makeText(this,"السعر غير صحيح",Toast.LENGTH_SHORT).show();}});
            row.addView(tv("المنتج",14,true));row.addView(name);row.addView(tv("القسم",14,true));row.addView(cat);row.addView(tv("السعر",14,true));row.addView(price);row.addView(offer);row.addView(save);
            Button img=btn("📷 رفع صورة للعرض");img.setOnClickListener(v->{mediaProductId=p.id;pickMedia(PICK_IMAGE,"image/*");});row.addView(img);
            Button vid=btn("🎥 رفع فيديو للعرض");vid.setOnClickListener(v->{mediaProductId=p.id;pickMedia(PICK_VIDEO,"video/*");});row.addView(vid);
            if(p.imageUrl!=null&&!p.imageUrl.isEmpty())row.addView(tv("✅ توجد صورة مرفوعة",14,true));if(p.videoUrl!=null&&!p.videoUrl.isEmpty())row.addView(tv("✅ يوجد فيديو مرفوع",14,true));
            Button delMedia=btn("🗑️ حذف صور/فيديو العرض");delMedia.setOnClickListener(v->{Map<String,Object> data=new HashMap<>();data.put("imageUrl",FieldValue.delete());data.put("videoUrl",FieldValue.delete());db.collection("products").document(p.id).update(data).addOnSuccessListener(x->Toast.makeText(this,"تم حذف روابط الوسائط",Toast.LENGTH_SHORT).show()).addOnFailureListener(x->Toast.makeText(this,"تعذر الحذف",Toast.LENGTH_SHORT).show());});row.addView(delMedia);
            Button del=btn("🗑️ حذف المنتج");del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف المنتج؟").setMessage(p.name).setPositiveButton("حذف",(d,w)->db.collection("products").document(p.id).delete()).setNegativeButton("إلغاء",null).show());row.addView(del);
            list.addView(row);Space sp=new Space(this);list.addView(sp,new LinearLayout.LayoutParams(1,dp(10)));
        }
        Button add=btn("＋ إضافة منتج");add.setOnClickListener(v->addProduct());list.addView(add);Button logout=btn("تسجيل الخروج");logout.setOnClickListener(v->{auth.signOut();showHome();});list.addView(logout);
    }

    void pickMedia(int requestCode,String type){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(type);startActivityForResult(i,requestCode);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null||mediaProductId==null)return;Uri uri=data.getData();String mime=getContentResolver().getType(uri);if(requestCode==PICK_IMAGE&&(mime==null||!mime.startsWith("image/"))){Toast.makeText(this,"الملف المختار ليس صورة",Toast.LENGTH_SHORT).show();return;}if(requestCode==PICK_VIDEO&&(mime==null||!mime.startsWith("video/"))){Toast.makeText(this,"الملف المختار ليس فيديو",Toast.LENGTH_SHORT).show();return;}uploadMedia(mediaProductId,uri,requestCode==PICK_IMAGE);}
    void uploadMedia(String productId,Uri uri,boolean image){if(auth.getCurrentUser()==null){Toast.makeText(this,"سجّل دخول الإدارة أولاً",Toast.LENGTH_SHORT).show();return;}String uid=auth.getCurrentUser().getUid();String path="offers/"+uid+"/"+productId+"_"+System.currentTimeMillis()+(image?".jpg":".mp4");StorageReference ref=storage.getReference().child(path);Toast.makeText(this,image?"جارٍ رفع الصورة...":"جارٍ رفع الفيديو...",Toast.LENGTH_LONG).show();ref.putFile(uri).continueWithTask(task->{if(!task.isSuccessful())throw task.getException();return ref.getDownloadUrl();}).addOnSuccessListener(url->{Map<String,Object> data=new HashMap<>();if(image)data.put("imageUrl",url.toString());else data.put("videoUrl",url.toString());db.collection("products").document(productId).update(data).addOnSuccessListener(x->{Toast.makeText(this,"تم رفع الوسائط بنجاح ✅",Toast.LENGTH_SHORT).show();mediaProductId=null;}).addOnFailureListener(x->Toast.makeText(this,"تم رفع الملف لكن تعذر ربطه بالمنتج",Toast.LENGTH_LONG).show());}).addOnFailureListener(e->Toast.makeText(this,"فشل رفع الملف: "+(e.getMessage()==null?"تحقق من إعدادات التخزين":e.getMessage()),Toast.LENGTH_LONG).show());}

    void addProduct(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText n=new EditText(this);n.setHint("اسم المنتج");EditText p=new EditText(this);p.setHint("السعر");p.setInputType(2|8192);Spinner cat=new Spinner(this);String[] cats={"جاج","غنم","عجل"};cat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats));box.addView(n);box.addView(p);box.addView(cat);
        new AlertDialog.Builder(this).setTitle("منتج جديد").setView(box).setPositiveButton("إضافة",(d,w)->{try{String nn=n.getText().toString().trim();double np=Double.parseDouble(p.getText().toString());String id=db.collection("products").document().getId();Map<String,Object> data=new HashMap<>();data.put("name",nn);data.put("unit","كيلو");data.put("price",np);data.put("offer",false);data.put("category",cat.getSelectedItem().toString());db.collection("products").document(id).set(data).addOnSuccessListener(x->showAdmin());}catch(Exception e){Toast.makeText(this,"البيانات غير صحيحة",Toast.LENGTH_SHORT).show();}}).setNegativeButton("إلغاء",null).show();
    }

    static class Product{
        String id,name,unit,imageUrl,videoUrl,category;double price;boolean offer;
        Product(String i,String n,String u,double p,boolean o,String img,String vid,String c){id=i;name=n;unit=u;price=p;offer=o;imageUrl=img;videoUrl=vid;category=c;}
    }
}
